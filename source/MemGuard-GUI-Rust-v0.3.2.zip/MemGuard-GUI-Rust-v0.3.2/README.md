# MemGuard GUI 0.3

Rust + Win32 原生 Windows 内存管理工具。

## 这一版新增

- 真正的 Windows 主界面，不再只有托盘
- 实时显示：
  - 物理内存使用率
  - 已用 / 总内存 / 可用内存
  - 上次清理后的可用内存变化
  - 自动清理状态、阈值、冷却时间、累计清理次数
- 进程列表按 Working Set 从高到低排序
- 支持 Ctrl / Shift 多选进程
- `清理选中`：只清理你明确选择的进程
- `清理全部符合规则`：按自动清理规则执行
- `加入白名单`：所选进程以后不参与自动规则清理
- `移出白名单`
- `刷新进程`
- 托盘常驻
- 双击托盘：打开主界面
- 关闭主窗口：隐藏到托盘，不退出程序
- 开机自启
- 配置文件和日志

## 安全策略

主界面的进程列表默认不展示 Windows 核心进程和 Session 0 系统服务。

自动/规则清理：
- 跳过核心进程
- 跳过 Session 0
- 跳过白名单
- 只处理 Working Set >= `min_working_set_mb` 的进程

手动 `清理选中`：
- 允许手动选择普通用户进程
- 手动选择可以覆盖白名单保护（因为这是用户显式操作）
- 仍然不允许处理核心系统进程和 Session 0

## 编译

你之前已经下载过 `windows-sys 0.61.2`，正常会直接使用 Cargo 缓存。

```powershell
cd D:\MemGuard-GUI-Rust
cargo build --release
```

生成：

```text
target\release\memguard-gui.exe
```

## 默认配置

首次运行生成：

```text
%LOCALAPPDATA%\MemGuard\config.ini
```

默认：

```ini
threshold=88
interval_seconds=10
consecutive_checks=3
cooldown_seconds=900
min_working_set_mb=200
auto_clean=true
exclude=vmware-vmx
```

日志：

```text
%LOCALAPPDATA%\MemGuard\memguard.log
```

## 进程选择

列表中可以：

- 单击：选择一个
- Ctrl + 单击：选择多个不连续进程
- Shift + 单击：选择一段连续进程

选择后点击：

```text
清理选中
```

即可只对选择的 PID 调用 `EmptyWorkingSet`。

## 白名单

例如选中：

```text
vmware-vmx
chrome
```

然后点击：

```text
加入白名单
```

配置会自动变成类似：

```ini
exclude=chrome,vmware-vmx
```

白名单进程仍会显示在进程列表里，并带：

```text
[白名单]
```

但不会被自动/规则清理。


## 0.3.1 编译修正（windows-sys 0.61.2）

已针对实际 MSVC 编译错误修正：

- 删除 `UpdateWindow` 导入和调用；当前窗口创建后使用 `ShowWindow` 即可。
- 删除未使用的 `MoveWindow`。
- `LBS_NOTIFY` / `LBS_EXTENDEDSEL` / `LBS_NOINTEGRALHEIGHT` 显式转换为 `u32`。
- `BS_PUSHBUTTON` 显式转换为 `u32`。

原因是 `windows-sys` 是低层 Win32 raw binding，部分控件 style 常量在生成绑定中为 `i32`，
而 `CreateWindowExW` 的窗口 style 参数使用 `u32`。


## 0.3.2：进程组与白名单增强

本版针对多子进程程序优化：

### 白名单不是按 PID

白名单始终按“进程名”匹配。

例如只选中任意一个：

```text
chrome   PID 6180
```

点击：

```text
按名称加入白名单
```

配置写入：

```ini
exclude=chrome
```

此后所有：

```text
chrome.exe
```

无论有多少 PID，都会被自动清理规则跳过。

### 同名全选

选中任意一个 `chrome`，点击：

```text
同名全选
```

界面会自动选中列表里全部 `chrome` PID。

然后可以点击：

```text
清理选中
```

一次手动处理所有 Chrome 子进程。

### 通配前缀

配置文件进一步支持：

```ini
exclude=chrome*,msedge*,wps*,wechat*,vmware*
```

含义：

- `chrome*`：所有以 chrome 开头的进程名
- `msedge*`：Edge 进程族
- `wps*`：WPS 进程族
- `wechat*`：微信相关同前缀进程
- `vmware*`：VMware 相关同前缀进程

建议优先用精确名称，只在确实需要覆盖一整个进程族时使用 `*`。
