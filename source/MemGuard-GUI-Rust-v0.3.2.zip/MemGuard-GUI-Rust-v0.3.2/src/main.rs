#![windows_subsystem = "windows"]

use std::{
    collections::HashSet,
    env,
    ffi::c_void,
    fs::{self, OpenOptions},
    io::{Read, Write},
    mem::{size_of, zeroed},
    path::{Path, PathBuf},
    ptr::{null, null_mut},
    sync::{Mutex, OnceLock},
    time::{Duration, Instant},
};

use windows_sys::Win32::{
    Foundation::{
        CloseHandle, GetLastError, HINSTANCE, HWND, INVALID_HANDLE_VALUE, LPARAM, LRESULT, POINT,
        SYSTEMTIME, WPARAM,
    },
    Graphics::Gdi::{GetStockObject, DEFAULT_GUI_FONT},
    System::{
        Diagnostics::ToolHelp::{
            CreateToolhelp32Snapshot, Process32FirstW, Process32NextW, PROCESSENTRY32W,
            TH32CS_SNAPPROCESS,
        },
        LibraryLoader::GetModuleHandleW,
        ProcessStatus::{EmptyWorkingSet, GetProcessMemoryInfo, PROCESS_MEMORY_COUNTERS},
        Registry::{
            RegCloseKey, RegCreateKeyExW, RegDeleteValueW, RegOpenKeyExW, RegQueryValueExW,
            RegSetValueExW, HKEY, HKEY_CURRENT_USER, KEY_QUERY_VALUE, KEY_SET_VALUE,
            REG_OPTION_NON_VOLATILE, REG_SZ,
        },
        RemoteDesktop::ProcessIdToSessionId,
        SystemInformation::{GetLocalTime, GlobalMemoryStatusEx, MEMORYSTATUSEX},
        Threading::{
            GetCurrentProcessId, OpenProcess, PROCESS_QUERY_INFORMATION,
            PROCESS_QUERY_LIMITED_INFORMATION, PROCESS_SET_QUOTA,
        },
    },
    UI::{
        Shell::{
            ShellExecuteW, Shell_NotifyIconW, NIF_ICON, NIF_MESSAGE, NIF_TIP, NIM_ADD, NIM_DELETE,
            NIM_MODIFY, NOTIFYICONDATAW,
        },
        WindowsAndMessaging::{
            AppendMenuW, CreatePopupMenu, CreateWindowExW, DefWindowProcW, DestroyMenu,
            DispatchMessageW, GetCursorPos, GetMessageW, LoadCursorW, LoadIconW,
            PostQuitMessage, RegisterClassW, SendMessageW, SetForegroundWindow, SetTimer,
            SetWindowTextW, ShowWindow, TrackPopupMenu, TranslateMessage,
            BS_PUSHBUTTON, CW_USEDEFAULT, IDC_ARROW, IDI_APPLICATION, LB_ADDSTRING,
            LB_GETSELCOUNT, LB_GETSELITEMS, LB_RESETCONTENT, LB_SETSEL, LBS_EXTENDEDSEL, LBS_NOINTEGRALHEIGHT,
            LBS_NOTIFY, MF_CHECKED, MF_DISABLED, MF_GRAYED, MF_SEPARATOR, MF_STRING, MF_UNCHECKED,
            MSG, SW_HIDE, SW_SHOW, SW_SHOWNORMAL, TPM_BOTTOMALIGN, TPM_LEFTALIGN, TPM_RIGHTBUTTON,
            WM_APP, WM_CLOSE, WM_COMMAND, WM_DESTROY, WM_LBUTTONDBLCLK, WM_RBUTTONUP, WM_SETFONT,
            WM_SIZE, WM_TIMER, WNDCLASSW, WS_CAPTION, WS_CHILD, WS_EX_CLIENTEDGE,
            WS_MINIMIZEBOX, WS_OVERLAPPED, WS_SYSMENU, WS_VISIBLE, WS_VSCROLL,
        },
    },
};

const TRAY_UID: u32 = 1;
const WM_TRAYICON: u32 = WM_APP + 1;
const TIMER_ID: usize = 1001;

const CMD_SHOW: usize = 2000;
const CMD_CLEAN_ELIGIBLE: usize = 2001;
const CMD_TOGGLE_AUTO: usize = 2002;
const CMD_OPEN_CONFIG: usize = 2003;
const CMD_OPEN_LOG: usize = 2004;
const CMD_TOGGLE_STARTUP: usize = 2005;
const CMD_EXIT: usize = 2006;

const ID_PROCESS_LIST: usize = 3100;

const BTN_REFRESH: usize = 3001;
const BTN_CLEAN_SELECTED: usize = 3002;
const BTN_CLEAN_ELIGIBLE: usize = 3003;
const BTN_ADD_EXCLUDE: usize = 3004;
const BTN_REMOVE_EXCLUDE: usize = 3005;
const BTN_TOGGLE_AUTO: usize = 3006;
const BTN_CONFIG: usize = 3007;
const BTN_SELECT_SAME: usize = 3008;

const RUN_KEY: &str = r"Software\Microsoft\Windows\CurrentVersion\Run";
const RUN_VALUE: &str = "MemGuardGui";

static APP: OnceLock<Mutex<AppState>> = OnceLock::new();

static mut HWND_MEM_TITLE: HWND = null_mut();
static mut HWND_MEM_BAR: HWND = null_mut();
static mut HWND_MEM_DETAIL: HWND = null_mut();
static mut HWND_AUTO_STATUS: HWND = null_mut();
static mut HWND_LIST: HWND = null_mut();
static mut HWND_STATUS: HWND = null_mut();

#[derive(Clone)]
struct Config {
    threshold: f64,
    interval_seconds: u64,
    consecutive_checks: u32,
    cooldown_seconds: u64,
    min_working_set_mb: u64,
    auto_clean: bool,
    excludes: HashSet<String>,
}

impl Default for Config {
    fn default() -> Self {
        let mut excludes = HashSet::new();
        excludes.insert("vmware-vmx".to_string());

        Self {
            threshold: 88.0,
            interval_seconds: 10,
            consecutive_checks: 3,
            cooldown_seconds: 900,
            min_working_set_mb: 200,
            auto_clean: true,
            excludes,
        }
    }
}

#[derive(Clone)]
struct ProcessRow {
    pid: u32,
    name: String,
    ws_mb: u64,
    excluded: bool,
}

struct AppState {
    config: Config,
    config_path: PathBuf,
    log_path: PathBuf,
    high_count: u32,
    last_clean: Option<Instant>,
    last_mem: MemoryInfo,
    last_freed_mb: f64,
    total_clean_count: u64,
    process_rows: Vec<ProcessRow>,
}

#[derive(Clone, Copy, Default)]
struct MemoryInfo {
    total_mb: f64,
    used_mb: f64,
    available_mb: f64,
    used_percent: f64,
}

#[derive(Default)]
struct TrimResult {
    trimmed: u32,
    skipped: u32,
    failed: u32,
}

fn main() {
    let base_dir = local_app_dir();
    let config_path = base_dir.join("config.ini");
    let log_path = base_dir.join("memguard.log");

    let _ = fs::create_dir_all(&base_dir);

    if !config_path.exists() {
        let _ = save_config(&config_path, &Config::default());
    }

    let config = load_config(&config_path).unwrap_or_default();
    let initial_mem = get_memory_info().unwrap_or_default();

    APP.set(Mutex::new(AppState {
        config,
        config_path,
        log_path,
        high_count: 0,
        last_clean: None,
        last_mem: initial_mem,
        last_freed_mb: 0.0,
        total_clean_count: 0,
        process_rows: Vec::new(),
    }))
    .ok();

    log("MemGuard GUI 启动。");

    unsafe {
        let hinstance = GetModuleHandleW(null());
        if hinstance.is_null() {
            log("GetModuleHandleW 失败。");
            return;
        }

        let class_name = wide("MemGuardGuiWindow");
        let wc = WNDCLASSW {
            style: 0,
            lpfnWndProc: Some(wnd_proc),
            cbClsExtra: 0,
            cbWndExtra: 0,
            hInstance: hinstance as HINSTANCE,
            hIcon: LoadIconW(null_mut(), IDI_APPLICATION),
            hCursor: LoadCursorW(null_mut(), IDC_ARROW),
            hbrBackground: (6usize) as *mut c_void,
            lpszMenuName: null(),
            lpszClassName: class_name.as_ptr(),
        };

        if RegisterClassW(&wc) == 0 {
            log(&format!("RegisterClassW 失败：{}", GetLastError()));
            return;
        }

        let title = wide("MemGuard - Windows 内存管理");
        let style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_VISIBLE;

        let hwnd = CreateWindowExW(
            0,
            class_name.as_ptr(),
            title.as_ptr(),
            style,
            CW_USEDEFAULT,
            CW_USEDEFAULT,
            820,
            650,
            null_mut(),
            null_mut(),
            hinstance as HINSTANCE,
            null_mut(),
        );

        if hwnd.is_null() {
            log(&format!("CreateWindowExW 失败：{}", GetLastError()));
            return;
        }

        create_controls(hwnd, hinstance as HINSTANCE);
        add_tray_icon(hwnd);
        refresh_dashboard(hwnd);
        refresh_process_list();

        let interval_ms = {
            let state = APP.get().unwrap().lock().unwrap();
            state.config.interval_seconds.saturating_mul(1000).max(1000)
        };
        SetTimer(hwnd, TIMER_ID, interval_ms as u32, None);

        ShowWindow(hwnd, SW_SHOW);

        let mut msg: MSG = zeroed();
        while GetMessageW(&mut msg, null_mut(), 0, 0) > 0 {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
}

unsafe fn create_controls(hwnd: HWND, hinstance: HINSTANCE) {
    let font = GetStockObject(DEFAULT_GUI_FONT);

    HWND_MEM_TITLE = create_static(hwnd, hinstance, "物理内存", 24, 18, 760, 28);
    HWND_MEM_BAR = create_static(hwnd, hinstance, "", 24, 50, 760, 30);
    HWND_MEM_DETAIL = create_static(hwnd, hinstance, "", 24, 83, 760, 24);
    HWND_AUTO_STATUS = create_static(hwnd, hinstance, "", 24, 110, 760, 24);

    let process_title = create_static(
        hwnd,
        hinstance,
        "进程列表（按 Working Set 从高到低；Ctrl / Shift 可多选）",
        24,
        150,
        760,
        24,
    );

    HWND_LIST = CreateWindowExW(
        WS_EX_CLIENTEDGE,
        wide("LISTBOX").as_ptr(),
        null(),
        WS_CHILD
            | WS_VISIBLE
            | WS_VSCROLL
            | (LBS_NOTIFY as u32)
            | (LBS_EXTENDEDSEL as u32)
            | (LBS_NOINTEGRALHEIGHT as u32),
        24,
        178,
        760,
        300,
        hwnd,
        ID_PROCESS_LIST as isize as _,
        hinstance,
        null_mut(),
    );

    create_button(hwnd, hinstance, "刷新进程", BTN_REFRESH, 24, 494, 110, 34);
    create_button(
        hwnd,
        hinstance,
        "清理选中",
        BTN_CLEAN_SELECTED,
        142,
        494,
        110,
        34,
    );
    create_button(
        hwnd,
        hinstance,
        "清理全部符合规则",
        BTN_CLEAN_ELIGIBLE,
        260,
        494,
        150,
        34,
    );
    create_button(
        hwnd,
        hinstance,
        "同名全选",
        BTN_SELECT_SAME,
        418,
        494,
        110,
        34,
    );
    create_button(
        hwnd,
        hinstance,
        "自动清理",
        BTN_TOGGLE_AUTO,
        536,
        494,
        110,
        34,
    );
    create_button(
        hwnd,
        hinstance,
        "打开配置",
        BTN_CONFIG,
        654,
        494,
        130,
        34,
    );

    create_button(
        hwnd,
        hinstance,
        "按名称加入白名单",
        BTN_ADD_EXCLUDE,
        24,
        538,
        180,
        32,
    );
    create_button(
        hwnd,
        hinstance,
        "按名称移出白名单",
        BTN_REMOVE_EXCLUDE,
        212,
        538,
        180,
        32,
    );

    HWND_STATUS = create_static(hwnd, hinstance, "状态：就绪", 408, 543, 376, 24);

    let handles = [
        HWND_MEM_TITLE,
        HWND_MEM_BAR,
        HWND_MEM_DETAIL,
        HWND_AUTO_STATUS,
        process_title,
        HWND_LIST,
        HWND_STATUS,
    ];

    for h in handles {
        if !h.is_null() {
            SendMessageW(h, WM_SETFONT, font as usize, 1);
        }
    }
}

unsafe fn create_static(
    parent: HWND,
    hinstance: HINSTANCE,
    text: &str,
    x: i32,
    y: i32,
    w: i32,
    h: i32,
) -> HWND {
    CreateWindowExW(
        0,
        wide("STATIC").as_ptr(),
        wide(text).as_ptr(),
        WS_CHILD | WS_VISIBLE,
        x,
        y,
        w,
        h,
        parent,
        null_mut(),
        hinstance,
        null_mut(),
    )
}

unsafe fn create_button(
    parent: HWND,
    hinstance: HINSTANCE,
    text: &str,
    id: usize,
    x: i32,
    y: i32,
    w: i32,
    h: i32,
) -> HWND {
    let button = CreateWindowExW(
        0,
        wide("BUTTON").as_ptr(),
        wide(text).as_ptr(),
        WS_CHILD | WS_VISIBLE | (BS_PUSHBUTTON as u32),
        x,
        y,
        w,
        h,
        parent,
        id as isize as _,
        hinstance,
        null_mut(),
    );

    if !button.is_null() {
        let font = GetStockObject(DEFAULT_GUI_FONT);
        SendMessageW(button, WM_SETFONT, font as usize, 1);
    }

    button
}

unsafe extern "system" fn wnd_proc(
    hwnd: HWND,
    msg: u32,
    wparam: WPARAM,
    lparam: LPARAM,
) -> LRESULT {
    match msg {
        WM_TIMER => {
            if wparam == TIMER_ID {
                on_timer(hwnd);
            }
            0
        }

        WM_TRAYICON => {
            let mouse_msg = lparam as u32;

            if mouse_msg == WM_RBUTTONUP {
                show_tray_menu(hwnd);
            } else if mouse_msg == WM_LBUTTONDBLCLK {
                show_main_window(hwnd);
            }
            0
        }

        WM_COMMAND => {
            let id = (wparam & 0xffff) as usize;

            match id {
                BTN_REFRESH => {
                    refresh_process_list();
                    set_status("进程列表已刷新。");
                }
                BTN_CLEAN_SELECTED => clean_selected(hwnd),
                BTN_CLEAN_ELIGIBLE | CMD_CLEAN_ELIGIBLE => {
                    clean_eligible(hwnd, "手动清理全部符合规则进程")
                }
                BTN_ADD_EXCLUDE => add_selected_to_excludes(),
                BTN_REMOVE_EXCLUDE => remove_selected_from_excludes(),
                BTN_SELECT_SAME => select_same_name_rows(),
                BTN_TOGGLE_AUTO | CMD_TOGGLE_AUTO => toggle_auto(hwnd),
                BTN_CONFIG | CMD_OPEN_CONFIG => open_config(hwnd),
                CMD_OPEN_LOG => open_log(hwnd),
                CMD_TOGGLE_STARTUP => {
                    toggle_startup();
                    set_status(if startup_enabled() {
                        "开机自启已开启。"
                    } else {
                        "开机自启已关闭。"
                    });
                }
                CMD_SHOW => show_main_window(hwnd),
                CMD_EXIT => {
                    delete_tray_icon(hwnd);
                    PostQuitMessage(0);
                }
                _ => {}
            }

            0
        }

        WM_CLOSE => {
            ShowWindow(hwnd, SW_HIDE);
            set_status("主窗口已隐藏，程序继续在托盘运行。");
            0
        }

        WM_SIZE => {
            // 当前采用固定布局。保留消息处理，避免默认过程产生不必要刷新问题。
            let _ = lparam;
            DefWindowProcW(hwnd, msg, wparam, lparam)
        }

        WM_DESTROY => {
            delete_tray_icon(hwnd);
            PostQuitMessage(0);
            0
        }

        _ => DefWindowProcW(hwnd, msg, wparam, lparam),
    }
}

unsafe fn show_main_window(hwnd: HWND) {
    ShowWindow(hwnd, SW_SHOW);
    SetForegroundWindow(hwnd);
    refresh_dashboard(hwnd);
    refresh_process_list();
}

unsafe fn on_timer(hwnd: HWND) {
    let (cfg, should_clean) = {
        let app = APP.get().unwrap();
        let mut state = app.lock().unwrap();

        if let Ok(new_cfg) = load_config(&state.config_path) {
            state.config = new_cfg;
        }

        let mem = match get_memory_info() {
            Ok(v) => v,
            Err(_) => return,
        };

        state.last_mem = mem;

        if state.config.auto_clean && mem.used_percent >= state.config.threshold {
            state.high_count = state.high_count.saturating_add(1);
        } else {
            state.high_count = 0;
        }

        let cooldown_ok = match state.last_clean {
            None => true,
            Some(last) => last.elapsed() >= Duration::from_secs(state.config.cooldown_seconds),
        };

        let trigger = state.config.auto_clean
            && state.high_count >= state.config.consecutive_checks
            && cooldown_ok;

        (state.config.clone(), trigger)
    };

    refresh_dashboard(hwnd);

    if should_clean {
        log(&format!(
            "自动触发：内存连续达到 {:.1}% 阈值。",
            cfg.threshold
        ));
        clean_eligible(hwnd, "自动阈值触发");
    }
}

unsafe fn refresh_dashboard(hwnd: HWND) {
    let mem = get_memory_info().unwrap_or_default();

    let (cfg, last_freed, total_clean_count) = {
        let app = APP.get().unwrap();
        let mut state = app.lock().unwrap();
        state.last_mem = mem;
        (
            state.config.clone(),
            state.last_freed_mb,
            state.total_clean_count,
        )
    };

    let bar_len = 40usize;
    let filled = ((mem.used_percent / 100.0) * bar_len as f64)
        .round()
        .clamp(0.0, bar_len as f64) as usize;
    let bar = format!(
        "{}{}  {:.1}%",
        "█".repeat(filled),
        "░".repeat(bar_len.saturating_sub(filled)),
        mem.used_percent
    );

    set_text(HWND_MEM_TITLE, &format!("物理内存使用率：{:.1}%", mem.used_percent));
    set_text(HWND_MEM_BAR, &bar);
    set_text(
        HWND_MEM_DETAIL,
        &format!(
            "已用 {:.2} GB / 总计 {:.2} GB    可用 {:.2} GB    上次释放 {:+.0} MB",
            mem.used_mb / 1024.0,
            mem.total_mb / 1024.0,
            mem.available_mb / 1024.0,
            last_freed
        ),
    );
    set_text(
        HWND_AUTO_STATUS,
        &format!(
            "自动清理：{}    触发阈值：{:.0}%    连续检测：{} 次    冷却：{} 秒    累计清理：{} 次",
            if cfg.auto_clean { "开启" } else { "关闭" },
            cfg.threshold,
            cfg.consecutive_checks,
            cfg.cooldown_seconds,
            total_clean_count
        ),
    );

    refresh_tray(hwnd);
}

unsafe fn refresh_process_list() {
    if HWND_LIST.is_null() {
        return;
    }

    let cfg = {
        let state = APP.get().unwrap().lock().unwrap();
        state.config.clone()
    };

    let rows = enumerate_processes(&cfg);
    SendMessageW(HWND_LIST, LB_RESETCONTENT, 0, 0);

    for row in &rows {
        let marker = if row.excluded { " [白名单]" } else { "" };
        let line = format!(
            "{:<34}  PID {:>6}    {:>7} MB{}",
            row.name, row.pid, row.ws_mb, marker
        );
        let w = wide(&line);
        SendMessageW(HWND_LIST, LB_ADDSTRING, 0, w.as_ptr() as isize);
    }

    {
        let mut state = APP.get().unwrap().lock().unwrap();
        state.process_rows = rows;
    }
}

fn enumerate_processes(cfg: &Config) -> Vec<ProcessRow> {
    let critical = critical_processes();
    let mut rows = Vec::new();

    unsafe {
        let snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if snapshot == INVALID_HANDLE_VALUE {
            return rows;
        }

        let current_pid = GetCurrentProcessId();
        let mut entry: PROCESSENTRY32W = zeroed();
        entry.dwSize = size_of::<PROCESSENTRY32W>() as u32;

        let mut ok = Process32FirstW(snapshot, &mut entry);

        while ok != 0 {
            let pid = entry.th32ProcessID;
            let exe_name = utf16_z_to_string(&entry.szExeFile);
            let name = normalize_process_name(&exe_name);

            if pid == 0 || pid == current_pid || critical.contains(&name) {
                ok = Process32NextW(snapshot, &mut entry);
                continue;
            }

            let mut session_id = 0u32;
            if ProcessIdToSessionId(pid, &mut session_id) == 0 || session_id == 0 {
                ok = Process32NextW(snapshot, &mut entry);
                continue;
            }

            let handle = OpenProcess(
                PROCESS_QUERY_INFORMATION | PROCESS_QUERY_LIMITED_INFORMATION,
                0,
                pid,
            );

            if handle.is_null() {
                ok = Process32NextW(snapshot, &mut entry);
                continue;
            }

            if let Some(ws_mb) = process_working_set_mb(handle) {
                rows.push(ProcessRow {
                    pid,
                    name: name.clone(),
                    ws_mb,
                    excluded: is_excluded(&name, &cfg.excludes),
                });
            }

            CloseHandle(handle);
            ok = Process32NextW(snapshot, &mut entry);
        }

        CloseHandle(snapshot);
    }

    rows.sort_by(|a, b| b.ws_mb.cmp(&a.ws_mb).then_with(|| a.name.cmp(&b.name)));
    rows
}

unsafe fn selected_rows() -> Vec<ProcessRow> {
    if HWND_LIST.is_null() {
        return Vec::new();
    }

    let count = SendMessageW(HWND_LIST, LB_GETSELCOUNT, 0, 0) as i32;
    if count <= 0 {
        return Vec::new();
    }

    let mut indices = vec![0i32; count as usize];
    let copied = SendMessageW(
        HWND_LIST,
        LB_GETSELITEMS,
        count as usize,
        indices.as_mut_ptr() as isize,
    ) as i32;

    if copied <= 0 {
        return Vec::new();
    }

    let rows = {
        let state = APP.get().unwrap().lock().unwrap();
        state.process_rows.clone()
    };

    indices
        .into_iter()
        .take(copied as usize)
        .filter_map(|idx| rows.get(idx as usize).cloned())
        .collect()
}

unsafe fn clean_selected(hwnd: HWND) {
    let rows = selected_rows();

    if rows.is_empty() {
        set_status("请先在进程列表中选择一个或多个进程。");
        return;
    }

    let before = get_memory_info().unwrap_or_default();
    let result = trim_specific_processes(&rows);
    let after = get_memory_info().unwrap_or(before);
    let freed = after.available_mb - before.available_mb;

    {
        let mut state = APP.get().unwrap().lock().unwrap();
        state.last_clean = Some(Instant::now());
        state.last_freed_mb = freed;
        state.total_clean_count += 1;
        state.high_count = 0;
    }

    log(&format!(
        "清理选中进程：选择={} 成功={} 跳过={} 失败={}，可用内存变化={:+.0} MB",
        rows.len(),
        result.trimmed,
        result.skipped,
        result.failed,
        freed
    ));

    set_status(&format!(
        "选中 {} 个进程，成功清理 {} 个，可用内存变化 {:+.0} MB。",
        rows.len(),
        result.trimmed,
        freed
    ));

    refresh_dashboard(hwnd);
    refresh_process_list();
}

unsafe fn clean_eligible(hwnd: HWND, reason: &str) {
    let cfg = {
        let state = APP.get().unwrap().lock().unwrap();
        state.config.clone()
    };

    let before = match get_memory_info() {
        Ok(v) => v,
        Err(e) => {
            set_status(&format!("读取内存失败：{e}"));
            return;
        }
    };

    log(&format!(
        "{reason}：RAM {:.1}%，开始处理 Working Set >= {} MB 的普通进程。",
        before.used_percent, cfg.min_working_set_mb
    ));

    let result = trim_working_sets(&cfg);
    let after = get_memory_info().unwrap_or(before);
    let freed = after.available_mb - before.available_mb;

    {
        let mut state = APP.get().unwrap().lock().unwrap();
        state.last_clean = Some(Instant::now());
        state.last_freed_mb = freed;
        state.total_clean_count += 1;
        state.high_count = 0;
        state.last_mem = after;
    }

    log(&format!(
        "完成：处理={} 跳过={} 失败={}；可用内存变化={:+.0} MB；RAM {:.1}% -> {:.1}%",
        result.trimmed,
        result.skipped,
        result.failed,
        freed,
        before.used_percent,
        after.used_percent
    ));

    set_status(&format!(
        "规则清理完成：成功 {} 个，释放变化 {:+.0} MB。",
        result.trimmed, freed
    ));

    refresh_dashboard(hwnd);
    refresh_process_list();
}

unsafe fn add_selected_to_excludes() {
    let rows = selected_rows();
    if rows.is_empty() {
        set_status("请选择要加入白名单的进程。");
        return;
    }

    let (save_result, names) = {
        let mut state = APP.get().unwrap().lock().unwrap();
        let mut names = Vec::new();

        for row in &rows {
            if state.config.excludes.insert(row.name.clone()) {
                names.push(row.name.clone());
            }
        }

        let result = save_config(&state.config_path, &state.config);
        (result, names)
    };

    if let Err(e) = save_result {
        set_status(&format!("保存白名单失败：{e}"));
        return;
    }

    if names.is_empty() {
        set_status("所选进程已经在白名单中。");
    } else {
        log(&format!("加入白名单：{}", names.join(", ")));
        set_status(&format!("已按进程名加入白名单：{}（所有同名 PID 均生效）", names.join(", ")));
    }

    refresh_process_list();
}

unsafe fn remove_selected_from_excludes() {
    let rows = selected_rows();
    if rows.is_empty() {
        set_status("请选择要移出白名单的进程。");
        return;
    }

    let (save_result, names) = {
        let mut state = APP.get().unwrap().lock().unwrap();
        let mut names = Vec::new();

        for row in &rows {
            if state.config.excludes.remove(&row.name) {
                names.push(row.name.clone());
            }
        }

        let result = save_config(&state.config_path, &state.config);
        (result, names)
    };

    if let Err(e) = save_result {
        set_status(&format!("保存白名单失败：{e}"));
        return;
    }

    if names.is_empty() {
        set_status("所选进程不在白名单中。");
    } else {
        log(&format!("移出白名单：{}", names.join(", ")));
        set_status(&format!("已按进程名移出白名单：{}", names.join(", ")));
    }

    refresh_process_list();
}


unsafe fn select_same_name_rows() {
    let selected = selected_rows();

    if selected.is_empty() {
        set_status("请先选择至少一个进程；程序会选中所有同名 PID。");
        return;
    }

    let names: HashSet<String> = selected.into_iter().map(|r| r.name).collect();

    let rows = {
        let state = APP.get().unwrap().lock().unwrap();
        state.process_rows.clone()
    };

    let mut count = 0usize;

    for (idx, row) in rows.iter().enumerate() {
        if names.contains(&row.name) {
            SendMessageW(HWND_LIST, LB_SETSEL, 1, idx as isize);
            count += 1;
        }
    }

    let mut sorted_names: Vec<_> = names.into_iter().collect();
    sorted_names.sort();

    set_status(&format!(
        "已选中 {} 个同名进程：{}",
        count,
        sorted_names.join(", ")
    ));
}

fn trim_specific_processes(rows: &[ProcessRow]) -> TrimResult {
    let critical = critical_processes();
    let current_pid = unsafe { GetCurrentProcessId() };
    let mut result = TrimResult::default();

    for row in rows {
        if row.pid == 0 || row.pid == current_pid || critical.contains(&row.name) {
            result.skipped += 1;
            continue;
        }

        unsafe {
            let mut session_id = 0u32;
            if ProcessIdToSessionId(row.pid, &mut session_id) == 0 || session_id == 0 {
                result.skipped += 1;
                continue;
            }

            let handle = OpenProcess(
                PROCESS_SET_QUOTA
                    | PROCESS_QUERY_INFORMATION
                    | PROCESS_QUERY_LIMITED_INFORMATION,
                0,
                row.pid,
            );

            if handle.is_null() {
                result.failed += 1;
                continue;
            }

            let before_ws = process_working_set_mb(handle).unwrap_or(row.ws_mb);

            if EmptyWorkingSet(handle) != 0 {
                result.trimmed += 1;
                log(&format!(
                    "手动已收缩：{} PID={} 原WorkingSet={} MB",
                    row.name, row.pid, before_ws
                ));
            } else {
                result.failed += 1;
            }

            CloseHandle(handle);
        }
    }

    result
}

unsafe fn toggle_auto(hwnd: HWND) {
    let (save_result, enabled) = {
        let mut state = APP.get().unwrap().lock().unwrap();
        state.config.auto_clean = !state.config.auto_clean;
        state.high_count = 0;

        let enabled = state.config.auto_clean;
        let save_result = save_config(&state.config_path, &state.config);
        (save_result, enabled)
    };

    if let Err(e) = save_result {
        set_status(&format!("保存配置失败：{e}"));
    } else {
        let msg = if enabled {
            "自动清理已开启。"
        } else {
            "自动清理已关闭。"
        };
        log(msg);
        set_status(msg);
    }

    refresh_dashboard(hwnd);
}

unsafe fn show_tray_menu(hwnd: HWND) {
    refresh_dashboard(hwnd);

    let (mem, cfg) = {
        let state = APP.get().unwrap().lock().unwrap();
        (state.last_mem, state.config.clone())
    };

    let menu = CreatePopupMenu();
    if menu.is_null() {
        return;
    }

    append_menu_text(menu, MF_STRING, CMD_SHOW, "打开主面板");

    let status = format!(
        "内存 {:.1}% | 可用 {:.1} GB",
        mem.used_percent,
        mem.available_mb / 1024.0
    );
    append_menu_text(menu, MF_STRING | MF_DISABLED | MF_GRAYED, 0, &status);

    AppendMenuW(menu, MF_SEPARATOR, 0, null());
    append_menu_text(menu, MF_STRING, CMD_CLEAN_ELIGIBLE, "清理全部符合规则进程");

    let auto_flags = MF_STRING
        | if cfg.auto_clean {
            MF_CHECKED
        } else {
            MF_UNCHECKED
        };
    append_menu_text(menu, auto_flags, CMD_TOGGLE_AUTO, "自动清理");

    AppendMenuW(menu, MF_SEPARATOR, 0, null());
    append_menu_text(menu, MF_STRING, CMD_OPEN_CONFIG, "打开配置");
    append_menu_text(menu, MF_STRING, CMD_OPEN_LOG, "打开日志");

    let startup_flags = MF_STRING
        | if startup_enabled() {
            MF_CHECKED
        } else {
            MF_UNCHECKED
        };
    append_menu_text(menu, startup_flags, CMD_TOGGLE_STARTUP, "开机自启");

    AppendMenuW(menu, MF_SEPARATOR, 0, null());
    append_menu_text(menu, MF_STRING, CMD_EXIT, "退出");

    let mut pt = POINT { x: 0, y: 0 };
    GetCursorPos(&mut pt);
    SetForegroundWindow(hwnd);

    TrackPopupMenu(
        menu,
        TPM_LEFTALIGN | TPM_BOTTOMALIGN | TPM_RIGHTBUTTON,
        pt.x,
        pt.y,
        0,
        hwnd,
        null(),
    );

    DestroyMenu(menu);
}

unsafe fn append_menu_text(menu: *mut c_void, flags: u32, id: usize, text: &str) {
    let w = wide(text);
    AppendMenuW(menu, flags, id, w.as_ptr());
}

unsafe fn add_tray_icon(hwnd: HWND) {
    let mut nid: NOTIFYICONDATAW = zeroed();
    nid.cbSize = size_of::<NOTIFYICONDATAW>() as u32;
    nid.hWnd = hwnd;
    nid.uID = TRAY_UID;
    nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
    nid.uCallbackMessage = WM_TRAYICON;
    nid.hIcon = LoadIconW(null_mut(), IDI_APPLICATION);
    copy_wide_fixed(&mut nid.szTip, "MemGuard 正在运行");

    if Shell_NotifyIconW(NIM_ADD, &nid) == 0 {
        log("添加托盘图标失败。");
    }
}

unsafe fn delete_tray_icon(hwnd: HWND) {
    let mut nid: NOTIFYICONDATAW = zeroed();
    nid.cbSize = size_of::<NOTIFYICONDATAW>() as u32;
    nid.hWnd = hwnd;
    nid.uID = TRAY_UID;
    Shell_NotifyIconW(NIM_DELETE, &nid);
}

unsafe fn refresh_tray(hwnd: HWND) {
    let mem = get_memory_info().unwrap_or_default();
    let (auto_clean, threshold) = {
        let mut state = APP.get().unwrap().lock().unwrap();
        state.last_mem = mem;
        (state.config.auto_clean, state.config.threshold)
    };

    let tip = format!(
        "MemGuard | RAM {:.1}% | 自动:{} | 阈值:{:.0}%",
        mem.used_percent,
        if auto_clean { "ON" } else { "OFF" },
        threshold
    );

    let mut nid: NOTIFYICONDATAW = zeroed();
    nid.cbSize = size_of::<NOTIFYICONDATAW>() as u32;
    nid.hWnd = hwnd;
    nid.uID = TRAY_UID;
    nid.uFlags = NIF_TIP;
    copy_wide_fixed(&mut nid.szTip, &tip);
    Shell_NotifyIconW(NIM_MODIFY, &nid);
}

fn trim_working_sets(cfg: &Config) -> TrimResult {
    let critical = critical_processes();
    let mut result = TrimResult::default();

    unsafe {
        let snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if snapshot == INVALID_HANDLE_VALUE {
            result.failed += 1;
            return result;
        }

        let current_pid = GetCurrentProcessId();
        let mut entry: PROCESSENTRY32W = zeroed();
        entry.dwSize = size_of::<PROCESSENTRY32W>() as u32;

        let mut ok = Process32FirstW(snapshot, &mut entry);

        while ok != 0 {
            let pid = entry.th32ProcessID;
            let exe_name = utf16_z_to_string(&entry.szExeFile);
            let name = normalize_process_name(&exe_name);

            if pid == 0
                || pid == current_pid
                || critical.contains(&name)
                || is_excluded(&name, &cfg.excludes)
            {
                result.skipped += 1;
                ok = Process32NextW(snapshot, &mut entry);
                continue;
            }

            let mut session_id = 0u32;
            if ProcessIdToSessionId(pid, &mut session_id) == 0 || session_id == 0 {
                result.skipped += 1;
                ok = Process32NextW(snapshot, &mut entry);
                continue;
            }

            let handle = OpenProcess(
                PROCESS_SET_QUOTA
                    | PROCESS_QUERY_INFORMATION
                    | PROCESS_QUERY_LIMITED_INFORMATION,
                0,
                pid,
            );

            if handle.is_null() {
                result.failed += 1;
                ok = Process32NextW(snapshot, &mut entry);
                continue;
            }

            let ws_mb = match process_working_set_mb(handle) {
                Some(v) => v,
                None => {
                    result.failed += 1;
                    CloseHandle(handle);
                    ok = Process32NextW(snapshot, &mut entry);
                    continue;
                }
            };

            if ws_mb < cfg.min_working_set_mb {
                result.skipped += 1;
                CloseHandle(handle);
                ok = Process32NextW(snapshot, &mut entry);
                continue;
            }

            if EmptyWorkingSet(handle) != 0 {
                result.trimmed += 1;
                log(&format!(
                    "自动/规则已收缩：{} PID={} 原WorkingSet={} MB",
                    name, pid, ws_mb
                ));
            } else {
                result.failed += 1;
            }

            CloseHandle(handle);
            ok = Process32NextW(snapshot, &mut entry);
        }

        CloseHandle(snapshot);
    }

    result
}

unsafe fn process_working_set_mb(handle: *mut c_void) -> Option<u64> {
    let mut pmc: PROCESS_MEMORY_COUNTERS = zeroed();
    pmc.cb = size_of::<PROCESS_MEMORY_COUNTERS>() as u32;

    if GetProcessMemoryInfo(
        handle,
        &mut pmc,
        size_of::<PROCESS_MEMORY_COUNTERS>() as u32,
    ) == 0
    {
        return None;
    }

    Some(pmc.WorkingSetSize as u64 / 1024 / 1024)
}

fn get_memory_info() -> Result<MemoryInfo, String> {
    unsafe {
        let mut st: MEMORYSTATUSEX = zeroed();
        st.dwLength = size_of::<MEMORYSTATUSEX>() as u32;

        if GlobalMemoryStatusEx(&mut st) == 0 {
            return Err(format!("GlobalMemoryStatusEx 失败：{}", GetLastError()));
        }

        let total_mb = st.ullTotalPhys as f64 / 1024.0 / 1024.0;
        let available_mb = st.ullAvailPhys as f64 / 1024.0 / 1024.0;
        let used_mb = total_mb - available_mb;

        Ok(MemoryInfo {
            total_mb,
            used_mb,
            available_mb,
            used_percent: if total_mb > 0.0 {
                used_mb / total_mb * 100.0
            } else {
                0.0
            },
        })
    }
}


fn is_excluded(name: &str, patterns: &HashSet<String>) -> bool {
    let name = normalize_process_name(name);

    for raw_pattern in patterns {
        let pattern = raw_pattern.trim().to_ascii_lowercase();

        if pattern.is_empty() {
            continue;
        }

        // 精确进程名：chrome
        if !pattern.contains('*') {
            if name == normalize_process_name(&pattern) {
                return true;
            }
            continue;
        }

        // 支持最常用的前缀通配：chrome* / wps* / wechat*
        if let Some(prefix) = pattern.strip_suffix('*') {
            let prefix = normalize_process_name(prefix);
            if !prefix.is_empty() && name.starts_with(&prefix) {
                return true;
            }
        }
    }

    false
}

fn critical_processes() -> HashSet<String> {
    [
        "system",
        "idle",
        "registry",
        "memory compression",
        "smss",
        "csrss",
        "wininit",
        "services",
        "lsass",
        "winlogon",
        "fontdrvhost",
        "dwm",
        "svchost",
        "audiodg",
        "taskhostw",
        "sihost",
        "explorer",
        "searchhost",
        "startmenuexperiencehost",
        "shellexperiencehost",
    ]
    .into_iter()
    .map(str::to_string)
    .collect()
}

fn load_config(path: &Path) -> Result<Config, String> {
    let mut cfg = Config::default();

    if !path.exists() {
        return Ok(cfg);
    }

    let mut text = String::new();
    fs::File::open(path)
        .map_err(|e| e.to_string())?
        .read_to_string(&mut text)
        .map_err(|e| e.to_string())?;

    for raw_line in text.lines() {
        let line = raw_line.trim();

        if line.is_empty() || line.starts_with('#') || line.starts_with(';') {
            continue;
        }

        let Some((key, value)) = line.split_once('=') else {
            continue;
        };

        let key = key.trim().to_ascii_lowercase();
        let value = value.trim();

        match key.as_str() {
            "threshold" => {
                if let Ok(v) = value.parse::<f64>() {
                    if (1.0..=99.9).contains(&v) {
                        cfg.threshold = v;
                    }
                }
            }
            "interval_seconds" => {
                if let Ok(v) = value.parse::<u64>() {
                    cfg.interval_seconds = v.clamp(1, 3600);
                }
            }
            "consecutive_checks" => {
                if let Ok(v) = value.parse::<u32>() {
                    cfg.consecutive_checks = v.clamp(1, 100);
                }
            }
            "cooldown_seconds" => {
                if let Ok(v) = value.parse::<u64>() {
                    cfg.cooldown_seconds = v.min(86400);
                }
            }
            "min_working_set_mb" => {
                if let Ok(v) = value.parse::<u64>() {
                    cfg.min_working_set_mb = v.clamp(1, 1024 * 1024);
                }
            }
            "auto_clean" => {
                cfg.auto_clean = matches!(
                    value.to_ascii_lowercase().as_str(),
                    "1" | "true" | "yes" | "on"
                );
            }
            "exclude" | "excludes" => {
                cfg.excludes.clear();
                for item in value.split(',') {
                    let name = normalize_process_name(item);
                    if !name.is_empty() {
                        cfg.excludes.insert(name);
                    }
                }
            }
            _ => {}
        }
    }

    Ok(cfg)
}

fn save_config(path: &Path, cfg: &Config) -> Result<(), String> {
    let mut excludes: Vec<_> = cfg.excludes.iter().cloned().collect();
    excludes.sort();

    let text = format!(
r#"; MemGuard GUI 配置
; 修改后程序会自动重新读取。

threshold={:.1}
interval_seconds={}
consecutive_checks={}
cooldown_seconds={}
min_working_set_mb={}
auto_clean={}
exclude={}
"#,
        cfg.threshold,
        cfg.interval_seconds,
        cfg.consecutive_checks,
        cfg.cooldown_seconds,
        cfg.min_working_set_mb,
        if cfg.auto_clean { "true" } else { "false" },
        excludes.join(",")
    );

    fs::write(path, text).map_err(|e| e.to_string())
}

unsafe fn open_config(hwnd: HWND) {
    let path = {
        let state = APP.get().unwrap().lock().unwrap();
        state.config_path.clone()
    };
    open_path(hwnd, &path);
}

unsafe fn open_log(hwnd: HWND) {
    let path = {
        let state = APP.get().unwrap().lock().unwrap();
        if !state.log_path.exists() {
            let _ = fs::write(&state.log_path, "");
        }
        state.log_path.clone()
    };
    open_path(hwnd, &path);
}

unsafe fn open_path(hwnd: HWND, path: &Path) {
    let operation = wide("open");
    let target = wide(&path.to_string_lossy());

    ShellExecuteW(
        hwnd,
        operation.as_ptr(),
        target.as_ptr(),
        null(),
        null(),
        SW_SHOWNORMAL,
    );
}

fn startup_enabled() -> bool {
    unsafe {
        let mut key: HKEY = null_mut();
        let run_key = wide(RUN_KEY);

        if RegOpenKeyExW(
            HKEY_CURRENT_USER,
            run_key.as_ptr(),
            0,
            KEY_QUERY_VALUE,
            &mut key,
        ) != 0
        {
            return false;
        }

        let value_name = wide(RUN_VALUE);
        let status = RegQueryValueExW(
            key,
            value_name.as_ptr(),
            null_mut(),
            null_mut(),
            null_mut(),
            null_mut(),
        );

        RegCloseKey(key);
        status == 0
    }
}

fn toggle_startup() {
    if startup_enabled() {
        if let Err(e) = disable_startup() {
            log(&format!("关闭开机自启失败：{e}"));
        } else {
            log("开机自启：已关闭。");
        }
    } else if let Err(e) = enable_startup() {
        log(&format!("开启开机自启失败：{e}"));
    } else {
        log("开机自启：已开启。");
    }
}

fn enable_startup() -> Result<(), String> {
    unsafe {
        let exe = env::current_exe().map_err(|e| e.to_string())?;
        let command = format!("\"{}\"", exe.to_string_lossy());

        let mut key: HKEY = null_mut();
        let run_key = wide(RUN_KEY);

        let status = RegCreateKeyExW(
            HKEY_CURRENT_USER,
            run_key.as_ptr(),
            0,
            null_mut(),
            REG_OPTION_NON_VOLATILE,
            KEY_SET_VALUE,
            null(),
            &mut key,
            null_mut(),
        );

        if status != 0 {
            return Err(format!("RegCreateKeyExW={status}"));
        }

        let name = wide(RUN_VALUE);
        let data = wide(&command);

        let status = RegSetValueExW(
            key,
            name.as_ptr(),
            0,
            REG_SZ,
            data.as_ptr() as *const u8,
            (data.len() * 2) as u32,
        );

        RegCloseKey(key);

        if status != 0 {
            return Err(format!("RegSetValueExW={status}"));
        }

        Ok(())
    }
}

fn disable_startup() -> Result<(), String> {
    unsafe {
        let mut key: HKEY = null_mut();
        let run_key = wide(RUN_KEY);

        let status = RegOpenKeyExW(
            HKEY_CURRENT_USER,
            run_key.as_ptr(),
            0,
            KEY_SET_VALUE,
            &mut key,
        );

        if status != 0 {
            return Ok(());
        }

        let name = wide(RUN_VALUE);
        let status = RegDeleteValueW(key, name.as_ptr());
        RegCloseKey(key);

        if status != 0 {
            return Err(format!("RegDeleteValueW={status}"));
        }

        Ok(())
    }
}

unsafe fn set_text(hwnd: HWND, text: &str) {
    if hwnd.is_null() {
        return;
    }
    let w = wide(text);
    SetWindowTextW(hwnd, w.as_ptr());
}

fn set_status(text: &str) {
    unsafe {
        set_text(HWND_STATUS, &format!("状态：{text}"));
    }
}

fn log(message: &str) {
    let path = APP
        .get()
        .and_then(|app| app.lock().ok().map(|s| s.log_path.clone()))
        .unwrap_or_else(|| local_app_dir().join("memguard.log"));

    if let Some(parent) = path.parent() {
        let _ = fs::create_dir_all(parent);
    }

    let line = format!("[{}] {}\r\n", local_timestamp(), message);

    if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(path) {
        let _ = file.write_all(line.as_bytes());
    }
}

fn local_timestamp() -> String {
    unsafe {
        let mut st: SYSTEMTIME = zeroed();
        GetLocalTime(&mut st);

        format!(
            "{:04}-{:02}-{:02} {:02}:{:02}:{:02}",
            st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond
        )
    }
}

fn local_app_dir() -> PathBuf {
    env::var_os("LOCALAPPDATA")
        .map(PathBuf::from)
        .unwrap_or_else(|| env::current_dir().unwrap_or_else(|_| PathBuf::from(".")))
        .join("MemGuard")
}

fn normalize_process_name(name: &str) -> String {
    let lower = name.trim().to_ascii_lowercase();
    lower
        .strip_suffix(".exe")
        .unwrap_or(lower.as_str())
        .to_string()
}

fn utf16_z_to_string(buf: &[u16]) -> String {
    let end = buf.iter().position(|&c| c == 0).unwrap_or(buf.len());
    String::from_utf16_lossy(&buf[..end])
}

fn wide(text: &str) -> Vec<u16> {
    text.encode_utf16().chain(std::iter::once(0)).collect()
}

fn copy_wide_fixed<const N: usize>(dst: &mut [u16; N], text: &str) {
    let src: Vec<u16> = text.encode_utf16().collect();
    let count = src.len().min(N.saturating_sub(1));

    dst[..count].copy_from_slice(&src[..count]);
    dst[count] = 0;
}
